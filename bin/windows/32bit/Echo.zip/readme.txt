Made by Matthew Hyndman (almostmatt.com)

WASD to move, Mouse to shoot
Enemies block your circle of light, shoot them (at least twice).
You can hold the mouse button to shoot multiple times.
Blue areas are checkpoints and safe areas
Enemies that you kill stay dead even if you respawn.